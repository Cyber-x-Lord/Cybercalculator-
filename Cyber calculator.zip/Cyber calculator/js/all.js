		<!--
		
var ctx = document.getElementById('myChart');
	var myChart = new Chart(ctx, {
  	  type: "doughnut",
 	   data: {
     	   labels: ['Principal', 'Interest'],
    	    datasets: [{
        		label:"Amount",
       	     data: [100, 10],
       	     backgroundColor: [
              	  'rgba(255, 99, 132, 0.2)',
             	   'rgba(54, 162, 235, 0.2)',
            	    
         	   ],
         	   borderColor: [
             	   'rgba(255, 99, 132, 1)',
              	  'rgba(54, 162, 235, 1)',
	
        	    ],
            	borderWidth: 1
      	  }]
 	   },
    	options: {
     	  scales: {
          
          
        	}
  	  }

	});
	
	
	
	

	
		
		
function compounding_calc(){
	var principal = Number(document.getElementById("principal").value);
	var interest = Number(document.getElementById("interest").value);
	var year = Number(document.getElementById("year").value);
	var frequency = document.getElementById("frequency").value;

	switch(frequency){
		case "Yearly":
		frequency = 1;
		break;
		
		case "Half yearly":
		frequency = 2;
		break;
		
		case "Quaterly":
		frequency = 4;
		break;
		
		case "Monthly":
		frequency = 12
		break;
}
	interest = interest/100;
	
	let amount = principal*((1+(interest/frequency))**(frequency*year));
	

	document.getElementById("principal_result").innerHTML=Math.round(principal);
	document.getElementById("interest_result").innerHTML=Math.round(amount-principal);
	document.getElementById("amount_result").innerHTML=Math.round(amount);
	
	


	
	

	myChart.data.datasets[0].data[0]=principal;
	myChart.data.datasets[0].data[1]=amount-principal;
	myChart.update();


}





















			<!-- Simple interest -->
function simple_calc(){
	var principal = Number(document.getElementById("principal").value);
	var interest = Number(document.getElementById("interest").value);
	var time = Number(document.getElementById("year").value);
	

	

	var amount = principal+((principal*interest*time)/100);



	document.getElementById("principal_result").innerHTML=Math.round(principal);
	document.getElementById("interest_result").innerHTML=Math.round(amount-principal);
	document.getElementById("amount_result").innerHTML=Math.round(amount);
	
	
	myChart.data.datasets[0].data[0]=principal;
	myChart.data.datasets[0].data[1]=amount-principal;
	myChart.update();


}

	
	
	
	
	
function bmi(){
	var weight = Number(document.getElementById("weight").value);
	var height = Number(document.getElementById("height").value);
	var height_unit = document.getElementById("height_unit").value;
	var weight_unit = document.getElementById("weight_unit").value;
	var bmi_label = "";


	switch(weight_unit){
		case "kg":
		weight = weight*1;
		break;
		
		case "pounds":
		weight = weight/2.205;
		break;
}

	switch(height_unit){
		case "cm":
		height = height*1;
		break;
		
		case "inch":
		height = height*2.54;
		break;
		
		case "meters":
		height = height*100;
		break;
}

	var bmi = ((weight/height/height)*10000);
	
	



	
	if (bmi<18){bmi_label="Under weight"}
	else if (bmi>18 && bmi<25){bmi_label="Normal weight"}
	else if (bmi>25 && bmi<30){bmi_label="Over weight"}
	else{bmi_label="Obese"}
	
	document.getElementById("bmi").innerHTML=bmi.toFixed(1);
	document.getElementById("bmi_label").innerHTML=bmi_label;
	
}
	
	
	
	
	









const select = document.querySelectorAll('.currency');
    const number = document.getElementById("number");
    const output = document.getElementById("output");


    fetch('https://api.frankfurter.app/currencies').then((data) => data.json())
      .then((data) => {
        display(data);
      });


    function display(data) {
      const entries = Object.entries(data);
      for (var i = 0; i < entries.length; i++) {
        select[0].innerHTML += `<option value="${entries[i][0]}">${entries[i][0]} : ${entries[i][1]}</option>`;
        select[1].innerHTML += `<option value="${entries[i][0]}">${entries[i][0]} : ${entries[i][1]}</option>`;
      }
    }



    function updatevalue() {
      let currency1 = select[0].value;
      let currency2 = select[1].value;

      let value = number.value;


      if (currency1 != currency2) {
        convert(currency1, currency2, value);
      } else {
        alert("Choose Diffrent Currency");
      }
    }


    function convert(currency1, currency2, value) {
      const host = "api.frankfurter.app";

      fetch(`https://${host}/latest?amount=${value}&from=${currency1}&to=${currency2}`)
        .then((val) => val.json())
        .then((val) => {
          console.log(Object.values(val.rates)[0]);
          output.value = Object.values(val.rates)[0];
        });

    }









function percent_btn_tab(){
	var a = 7;
	document.getElementById("percent-btn").style.background="linear-gradient(45deg, #5433FF, #20BDFF, #A5FECB)";
	document.getElementById("value-btn").style.background="transparent";
	document.getElementById("submit-btn").setAttribute("onclick","percentage_calc()");
	document.getElementById("result-label").innerHTML= "Percentage : ";
	document.getElementById("label").innerHTML = "Enter the Value";
}

function value_btn_tab(){
	document.getElementById("value-btn").style.background="linear-gradient(45deg, #5433FF, #20BDFF, #A5FECB)";
	document.getElementById("percent-btn").style.background="transparent";
	document.getElementById("submit-btn").setAttribute("onclick","value_calc()");
	document.getElementById("result-label").innerHTML= "Value :  ";
	document.getElementById("label").innerHTML = "Enter the Percentage %";
	
}


function percentage_calc(){
		var percent_amount = Number(document.getElementById("percent_amount").value);
		var value = Number(document.getElementById("value").value);
		var value = (value/percent_amount)*100;
		
		document.getElementById("result").innerHTML= (value.toFixed(2))+"%";  
}

function value_calc(){
	var percent_amount = Number(document.getElementById("percent_amount").value);
	var  percentage = Number(document.getElementById("value").value);
	var value = (percentage/100)*percent_amount;
	
	document.getElementById("result").innerHTML= value;  
	
}




					