var formula;
var text;
var shape ;
var length ;
var pi_numerator;
var pi_denominator;

function pi_value(){
	var x = document.getElementById("pi").value;
	if(x == "22/7"){
	 pi_numerator = 22;
	 pi_denominator = 7;
	}
	else if(x == "3.14"){
	 pi_numerator = 314;
	 pi_denominator = 100;
	}
}

function opt_remove(){
	var div = document.getElementById("sides").children;
	var x = div[1];
	while(x){
		x.remove();
		 x = div[1];
	}
}
function result_clear(){
	<!--This clear all the elements in the results section-->
	var div2 = document.getElementById("result").children;
	var y = div2[0];
	while(y){
		y.remove();
		 y = div2[0];
	}
}


function surface_area(){
shape = document.getElementById("shape").value;

if(shape == "Cube"){
	document.getElementById("shape-img").setAttribute("src", "../img/cube.png");
	document.getElementById("radius").style.display ="none";
	document.getElementById("length").style.display ="block";
	document.getElementById("breadth").style.display ="none";
	document.getElementById("height").style.display ="none";
	document.getElementById("pi_section").style.display ="none";
	document.getElementById("calc-btn").setAttribute("onclick", "cube()");
	
	opt_remove();
	
	const option1 = document.createElement("option");
	const option2 = document.createElement("option");
	const option3 = document.createElement("option");
	const value1 = document.createTextNode("4 Sides Area");
	const value2 = document.createTextNode("5 Sides Area");
	const value3 = document.createTextNode("6 Sides Area");
	option1.appendChild(value1);
	option2.appendChild(value2);
	option3.appendChild(value3);
	document.getElementById("sides").appendChild(option1);
	document.getElementById("sides").appendChild(option2);
	document.getElementById("sides").appendChild(option3);
}
if(shape == "Cuboid"){
	
	document.getElementById("shape-img").setAttribute("src", "../img/cuboid.png");
	document.getElementById("radius").style.display ="none";
	document.getElementById("length").style.display ="block";
	document.getElementById("breadth").style.display ="block";
	document.getElementById("height").style.display ="block";
	document.getElementById("pi_section").style.display ="none";
	document.getElementById("calc-btn").setAttribute("onclick", "cuboid()");
	
	opt_remove();
	
	const option1 = document.createElement("option");
	const option2 = document.createElement("option");
	const option3 = document.createElement("option");
	const value1 = document.createTextNode("4 Sides Area");
	const value2 = document.createTextNode("5 Sides Area");
	const value3 = document.createTextNode("6 Sides Area");
	option1.appendChild(value1);
	option2.appendChild(value2);
	option3.appendChild(value3);
	document.getElementById("sides").appendChild(option1);
	document.getElementById("sides").appendChild(option2);
	document.getElementById("sides").appendChild(option3);
}
else if(shape == "Cone"){
	document.getElementById("shape-img").setAttribute("src", "../img/cone.png");
	document.getElementById("radius").style.display ="block";
	document.getElementById("length").style.display ="none";
	document.getElementById("breadth").style.display ="none";
	document.getElementById("height").style.display ="block";
	document.getElementById("pi_section").style.display ="block";
	document.getElementById("calc-btn").setAttribute("onclick", "cone()");
	
	opt_remove();
	
	document.getElementById("slant-height").innerHTML = "Slant Height";
	const option1 = document.createElement("option");
	const option2 = document.createElement("option");
	const option3 = document.createElement("option");
	const value1 = document.createTextNode("Curved Surface Area");
	const value2 = document.createTextNode("Curved Surface Area with base");
	option1.appendChild(value1);
	option2.appendChild(value2);
	document.getElementById("sides").appendChild(option1);
	document.getElementById("sides").appendChild(option2);
}
else if(shape == "Cylinder"){
	document.getElementById("shape-img").setAttribute("src", "../img/cylinder.png");
	document.getElementById("radius").style.display ="block";
	document.getElementById("length").style.display ="none";
	document.getElementById("breadth").style.display ="none";
	document.getElementById("height").style.display ="block";
	document.getElementById("pi_section").style.display ="block";
	document.getElementById("calc-btn").setAttribute("onclick", "cylinder()");
	
	opt_remove();
	
	const option1 = document.createElement("option");
	const option2 = document.createElement("option");
	const option3 = document.createElement("option");
	const value1 = document.createTextNode("Curved Surface Area");
	const value2 = document.createTextNode("Curved Surface Area with one base");
	const value3 = document.createTextNode("Curved Surface Area with both base");
	option1.appendChild(value1);
	option2.appendChild(value2);
	option3.appendChild(value3);
	document.getElementById("sides").appendChild(option1);
	document.getElementById("sides").appendChild(option2);
	document.getElementById("sides").appendChild(option3);
}
else if(shape == "Sphere"){
	document.getElementById("shape-img").setAttribute("src", "../img/sphere.png");
	document.getElementById("radius").style.display ="block";
	document.getElementById("length").style.display ="none";
	document.getElementById("breadth").style.display ="none";
	document.getElementById("height").style.display ="none";
	document.getElementById("pi_section").style.display ="block";
	document.getElementById("calc-btn").setAttribute("onclick", "sphere()");
	
	opt_remove();
	
	const option1 = document.createElement("option");
	const value1 = document.createTextNode("Curved Surface Area");
	option1.appendChild(value1);
	document.getElementById("sides").appendChild(option1);
}
else if(shape == "Hemisphere"){
	document.getElementById("shape-img").setAttribute("src", "../img/hemisphere.png");
	document.getElementById("radius").style.display ="block";
	document.getElementById("length").style.display ="none";
	document.getElementById("breadth").style.display ="none";
	document.getElementById("height").style.display ="none";
	document.getElementById("pi_section").style.display ="block";
	document.getElementById("calc-btn").setAttribute("onclick", "hemisphere()");
	
	opt_remove();
	
	const option1 = document.createElement("option");
	const option2 = document.createElement("option");
	const option3 = document.createElement("option");
	const value1 = document.createTextNode("Curved Surface Area");
	const value2 = document.createTextNode("Curved Surface Area with base");
	option1.appendChild(value1);
	option2.appendChild(value2);
	document.getElementById("sides").appendChild(option1);
	document.getElementById("sides").appendChild(option2);
}
}

function cube(){
	 result_clear()
	
	length = document.getElementById("length-value").value;
	
	const opt = document.getElementById("sides").value;
		if(opt == "4 Sides Area"){
		formula = 4*(length*length);
		var formulaText = "4*(length*length)";
		}
		else if(opt == "5 Sides Area"){
			formula = 5*(length*length);
			formulaText = "5*(length*length)";
		}
		else if(opt == "6 Sides Area"){
			formula = 6*(length*length);
			formulaText = "6*(length*length)";
		}

	const para = document.createElement("p");
	const node = document.createTextNode(`Formula = ${formulaText}`);
	para.appendChild(node);
	document.getElementById("result").appendChild(para);
	
	const step2 = document.createElement("p");
	const result = formula;
	console.log(result);
	const node2 = document.createTextNode(result.toFixed(2));
	step2.appendChild(node2);
	document.getElementById("result").appendChild(step2);
}


function cuboid(){
	result_clear()

	var breadth = Number(document.getElementById("breadth-value").value);
	var height = Number(document.getElementById("height-value").value);
	var length = Number(document.getElementById("length-value").value);
	
	const opt = document.getElementById("sides").value;
		if(opt == "4 Sides Area"){
			formula = 2*height*(length+breadth);
			var formulaText = "2*height*(length+breadth)";
		}
		else if(opt == "5 Sides Area"){
			formula = (2*height*(length+breadth))+(length*breadth);
			formulaText = "(2*height*(length+breadth))+(length*breadth)"; 
		}
		else if(opt == "6 Sides Area"){
			formula = 2*((length*breadth)+(length*height)+(breadth*height));
			formulaText = "2*((length*breadth)+(length*height)+(breadth*height))";
		}
	
	const para = document.createElement("p");
	const node = document.createTextNode(`Formula = ${formulaText}`);
	para.appendChild(node);
	document.getElementById("result").appendChild(para);
	
	const step2 = document.createElement("p");
	const result = formula;
	const node2 = document.createTextNode(result.toFixed(2));
	step2.appendChild(node2);
	document.getElementById("result").appendChild(step2);
}





function sphere(){
	result_clear()

	var radius = document.getElementById("radius-value").value;
	
	const para = document.createElement("p");
	const node = document.createTextNode("Formula = 4πr²");
	para.appendChild(node);
	document.getElementById("result").appendChild(para);
	
	const step1 = document.createElement("p");
	const node1 = document.createTextNode(`4*π * ${radius}²`);
	step1.appendChild(node1);
	document.getElementById("result").appendChild(step1);
	
	const step2 = document.createElement("p");
	var result = (4*pi_numerator*radius*radius)/pi_denominator;
	const node2 = document.createTextNode(result.toFixed(2));
	step2.appendChild(node2);
	document.getElementById("result").appendChild(step2);
	
}



function hemisphere(){
	result_clear()

	var radius = document.getElementById("radius-value").value;
	const opt = document.getElementById("sides").value;
		if(opt == "Curved Surface Area"){
			formula = (2*(pi_numerator*radius*radius))/pi_denominator;
			var formulaText = "2πr²";
		}
		else if(opt == "Curved Surface Area with base"){
			formula = (3*(pi_numerator*radius*radius))/pi_denominator;
			 formulaText = "3πr²";
		}
	
	const para = document.createElement("p");
	const node = document.createTextNode(`Formula = ${formulaText}`);
	para.appendChild(node);
	document.getElementById("result").appendChild(para);
	
	const step2 = document.createElement("p");
	var result = formula;
	const node2 = document.createTextNode(result.toFixed(2));
	step2.appendChild(node2);
	document.getElementById("result").appendChild(step2);
}





function cylinder(){
	result_clear()

	var radius = document.getElementById("radius-value").value;
	var height = document.getElementById("height-value").value;
	const opt = document.getElementById("sides").value;
		if(opt == "Curved Surface Area"){
			formula = (2*(pi_numerator*radius*height))/pi_denominator;
			var formulaText = "2πrh";
		}
		else if(opt == "Curved Surface Area with one base"){
			formula = ((2*(pi_numerator*radius*height))/pi_denominator) + ((pi_numerator*radius*radius)/pi_denominator);
			var formulaText = "2πrh+πr²";
		}
		else if(opt == "Curved Surface Area with both base"){
			formula = ((2*(pi_numerator*radius*height))/pi_denominator) + (2((pi_numerator*radius*radius)/pi_denominator));
			var formulaText = "2πrh+2πr²";
		}
	
	const para = document.createElement("p");
	const node = document.createTextNode(`Formula = ${formulaText}`);
	para.appendChild(node);
	document.getElementById("result").appendChild(para);
	
	const step2 = document.createElement("p");
	var result = formula;
	const node2 = document.createTextNode(result.toFixed(2));
	step2.appendChild(node2);
	document.getElementById("result").appendChild(step2);
}


function cone(){
	result_clear()

	var radius = document.getElementById("radius-value").value;
	var height = document.getElementById("height-value").value;
	
	const opt = document.getElementById("sides").value;
		if(opt == "Curved Surface Area"){
			formula = (pi_numerator*radius*height)/pi_denominator;
			var formulaText = "πrl";
		}
		else if(opt == "Curved Surface Area with base"){
			formula = ((pi_numerator*radius*height)/pi_denominator)+((pi_numerator*radius*radius)/pi_denominator);
			 formulaText = "πrl+πr²";
		}
	
	const para = document.createElement("p");
	const node = document.createTextNode(`Formula = ${formulaText}`);
	para.appendChild(node);
	document.getElementById("result").appendChild(para);
	
	const step2 = document.createElement("p");
	var result = formula;
	const node2 = document.createTextNode(result.toFixed(2));
	step2.appendChild(node2);
	document.getElementById("result").appendChild(step2);
}

