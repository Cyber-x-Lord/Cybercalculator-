<!--Volume-->

var pi_numerator;
var pi_denominator;

function pi_value(){
	var x = document.getElementById("pi").value;
	if(x == "22/7"){
	 pi_numerator = 22;
	 pi_denominator = 7;
	}
	else if(x == "3.14"){
	 pi_numerator = 314;
	 pi_denominator = 100;
	}
}


function result_clear(){
	<!--This clear all the elements in the results section-->
	var div2 = document.getElementById("result").children;
	var y = div2[0];
	while(y){
		y.remove();
		 y = div2[0];
	}
}


function volume(){
var shape = document.getElementById("shape").value;

if(shape == "Cube"){
	document.getElementById("shape-img").setAttribute("src", "../img/cube.png");
	document.getElementById("radius").style.display ="none";
	document.getElementById("length").style.display ="block";
	document.getElementById("breadth").style.display ="none";
	document.getElementById("height").style.display ="none";
	document.getElementById("pi_section").style.display ="none";
	document.getElementById("calc-btn").setAttribute("onclick", "cube()");
}
if(shape == "Cuboid"){
	document.getElementById("shape-img").setAttribute("src", "../img/cuboid.png");
	document.getElementById("radius").style.display ="none";
	document.getElementById("length").style.display ="block";
	document.getElementById("breadth").style.display ="block";
	document.getElementById("height").style.display ="block";
	document.getElementById("pi_section").style.display ="none";
	document.getElementById("calc-btn").setAttribute("onclick", "cuboid()");
}
else if(shape == "Cone"){
	document.getElementById("shape-img").setAttribute("src", "../img/cone.png");
	document.getElementById("radius").style.display ="block";
	document.getElementById("length").style.display ="none";
	document.getElementById("breadth").style.display ="none";
	document.getElementById("height").style.display ="block";
	document.getElementById("pi_section").style.display ="block";
	document.getElementById("calc-btn").setAttribute("onclick", "cone()");
	
	 
}
else if(shape == "Cylinder"){
	document.getElementById("shape-img").setAttribute("src", "../img/cylinder.png");
	document.getElementById("radius").style.display ="block";
	document.getElementById("length").style.display ="none";
	document.getElementById("breadth").style.display ="none";
	document.getElementById("height").style.display ="block";
	document.getElementById("pi_section").style.display ="block";
	document.getElementById("calc-btn").setAttribute("onclick", "cylinder()");
	 
}
else if(shape == "Sphere"){
	document.getElementById("shape-img").setAttribute("src", "../img/sphere.png");
	document.getElementById("radius").style.display ="block";
	document.getElementById("length").style.display ="none";
	document.getElementById("breadth").style.display ="none";
	document.getElementById("height").style.display ="none";
	document.getElementById("pi_section").style.display ="block";
	document.getElementById("calc-btn").setAttribute("onclick", "sphere()");
}
else if(shape == "Hemisphere"){
	document.getElementById("shape-img").setAttribute("src", "../img/hemisphere.png");
	document.getElementById("radius").style.display ="block";
	document.getElementById("length").style.display ="none";
	document.getElementById("breadth").style.display ="none";
	document.getElementById("height").style.display ="none";
	document.getElementById("pi_section").style.display ="block";
	document.getElementById("calc-btn").setAttribute("onclick", "hemisphere()");
	 
}
}

function cube(){
	 result_clear()
	var length = document.getElementById("length-value").value;
	const formula = document.createElement("p");
	const node = document.createTextNode("Formula = (Side)³");
	formula.appendChild(node);
	document.getElementById("result").appendChild(formula);
	
	const step1 = document.createElement("p");
	const node1 = document.createTextNode(`(${length})³`);
	step1.appendChild(node1);
	document.getElementById("result").appendChild(step1);
	
	const step2 = document.createElement("p");
	const result = length*length*length;
	const node2 = document.createTextNode(result.toFixed(2));
	step2.appendChild(node2);
	document.getElementById("result").appendChild(step2);
}


function cuboid(){
	result_clear()

	var breadth = document.getElementById("breadth-value").value;
	var height = document.getElementById("height-value").value;
	var length = document.getElementById("length-value").value;
	
	const formula = document.createElement("p");
	const node = document.createTextNode("Formula = length * Breadth * Height");
	formula.appendChild(node);
	document.getElementById("result").appendChild(formula);
	
	const step1 = document.createElement("p");
	const node1 = document.createTextNode(`${length} * ${breadth} * ${height}`);
	step1.appendChild(node1);
	document.getElementById("result").appendChild(step1);
	
	const step2 = document.createElement("p");
	const result = length*breadth*height;
	const node2 = document.createTextNode(result.toFixed(2));
	step2.appendChild(node2);
	document.getElementById("result").appendChild(step2);
	
	
}


function sphere(){
	result_clear();
	
	var radius = document.getElementById("radius-value").value;
	
	const formula = document.createElement("p");
	const node = document.createTextNode("Formula = 4/3(πr³)");
	formula.appendChild(node);
	document.getElementById("result").appendChild(formula);
	
	const step1 = document.createElement("p");
	const node1 = document.createTextNode(`4/3(π * ${radius}³)`);
	step1.appendChild(node1);
	document.getElementById("result").appendChild(step1);
	
	const step2 = document.createElement("p");
	var result = (4*pi_numerator*radius*radius*radius)/(3*pi_denominator);
	const node2 = document.createTextNode(result.toFixed(2));
	step2.appendChild(node2);
	document.getElementById("result").appendChild(step2);
	
}


function hemisphere(){
	result_clear()

	var radius = document.getElementById("radius-value").value;
	
	const formula = document.createElement("p");
	const node = document.createTextNode("Formula = 2/3(πr³)");
	formula.appendChild(node);
	document.getElementById("result").appendChild(formula);
	
	const step1 = document.createElement("p");
	const node1 = document.createTextNode(`2/3(π * ${radius}³)`);
	step1.appendChild(node1);
	document.getElementById("result").appendChild(step1);
	
	const step2 = document.createElement("p");
	var result = (2*pi_numerator*radius*radius*radius)/(3*pi_denominator);
	const node2 = document.createTextNode(result.toFixed(2));
	step2.appendChild(node2);
	document.getElementById("result").appendChild(step2);
	
}


function cylinder(){
		result_clear();
	
	var radius = document.getElementById("radius-value").value;
	var height = document.getElementById("height-value").value;
	
	const formula = document.createElement("p");
	const node = document.createTextNode("Formula = πr²h");
	formula.appendChild(node);
	document.getElementById("result").appendChild(formula);
	
	const step1 = document.createElement("p");
	const node1 = document.createTextNode(`π * ${radius}² * height`);
	step1.appendChild(node1);
	document.getElementById("result").appendChild(step1);
	
	const step2 = document.createElement("p");
	var result = ((pi_numerator*radius*radius*height)/pi_denominator);
	const node2 = document.createTextNode(result.toFixed(2));
	step2.appendChild(node2);
	document.getElementById("result").appendChild(step2);
}


function cone(){
	result_clear()

	var radius = document.getElementById("radius-value").value;
	var height = document.getElementById("height-value").value;
	
	const formula = document.createElement("p");
	const node = document.createTextNode("Formula = 1/3(πr²h)");
	formula.appendChild(node);
	document.getElementById("result").appendChild(formula);
	
	const step1 = document.createElement("p");
	const node1 = document.createTextNode(`1/3(π * ${radius}² * height)`);
	step1.appendChild(node1);
	document.getElementById("result").appendChild(step1);
	
	const step2 = document.createElement("p");
	var result = ((1*pi_numerator*radius*radius*height)/(3*pi_denominator));
	const node2 = document.createTextNode(result.toFixed(2));
	step2.appendChild(node2);
	document.getElementById("result").appendChild(step2);
	
}